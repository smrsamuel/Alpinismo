
const WA="5513999990000"; // TROQUE pelo WhatsApp real: DDI+DDD+número, sem espaços.
const makeWA=m=>"https://wa.me/"+WA+"?text="+encodeURIComponent(m);
document.querySelectorAll("[data-wa]").forEach(a=>{a.href=makeWA(a.dataset.wa);a.target="_blank"});
const menu=document.querySelector(".menu"),nav=document.querySelector(".nav-links");
if(menu)menu.onclick=()=>nav.classList.toggle("open");
document.querySelectorAll(".nav-links a").forEach(a=>a.onclick=()=>nav.classList.remove("open"));
document.querySelectorAll("form[data-form]").forEach(f=>f.onsubmit=e=>{
 e.preventDefault();let d=new FormData(f);
 let m=`Olá! Gostaria de solicitar um orçamento.%0A%0ANome: ${d.get("nome")||""}%0AEmpresa: ${d.get("empresa")||""}%0ATelefone: ${d.get("telefone")||""}%0AServiço/treinamento: ${d.get("servico")||""}%0AMensagem: ${d.get("mensagem")||""}`;
 location.href=makeWA(m);
});
